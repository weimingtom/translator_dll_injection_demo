#include <windows.h>

//GetTextMetricsA
BOOL WINAPI HookText(HDC hdc, LPTEXTMETRICA lptm)
{
	MessageBox(NULL, "HookText", "injectdll", MB_OK);
	return FALSE;
}

void Setup(void)
{
	HMODULE ImageBase;
	PIMAGE_NT_HEADERS PEHeader;
	PIMAGE_IMPORT_DESCRIPTOR PImport;
	FARPROC ProcAddress;
	BOOL Found;
	LPDWORD PRVA_Import;
	DWORD Old = 0;

	ImageBase = GetModuleHandle(NULL);
	PEHeader = (PIMAGE_NT_HEADERS)(((__int64)ImageBase) + ((PIMAGE_DOS_HEADER)ImageBase)->e_lfanew);
	PImport = (PIMAGE_IMPORT_DESCRIPTOR)(PEHeader->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT].VirtualAddress + (unsigned long)ImageBase);

	ProcAddress = GetProcAddress(GetModuleHandle("gdi32.dll"), "GetTextMetricsA");
	if(ProcAddress == NULL)
	{
		MessageBox(NULL, "GetProcAddress(TextOutA)", "injectdll", MB_OK);
		return ;
	}
	Found = FALSE;
	while (PImport->Name != 0)
	{
		//MessageBox(NULL, "001", "injectdll", MB_OK);
		PRVA_Import = (LPDWORD)(PImport->FirstThunk + (unsigned long)ImageBase);
		while (*PRVA_Import != 0)
		{
			//MessageBox(NULL, "002", "injectdll", MB_OK);
			if (*((void **)PRVA_Import) == (void *)ProcAddress)
			{
				Found = TRUE;
				if(!VirtualProtect((LPVOID)PRVA_Import, 4, PAGE_READWRITE, &Old))
				{
					MessageBox(NULL, "do- VirtualProtect()", "injectdll", MB_OK);
					return ;
				}
				*((void **)PRVA_Import) = (void *)HookText;
				if(!VirtualProtect((LPVOID)PRVA_Import, 4, Old, &Old))
				{
					MessageBox(NULL, "un- VirtualProtect()", "injectdll", MB_OK);
					return ;
				}
			}
			PRVA_Import++;
		}
		PImport++;
	}
	if (Found == FALSE)
	{
		MessageBox(NULL, "No GetTextMetricsA in the import table. Wrong EXE? Wrong game? Wrong version?", "injectdll", MB_OK);
		return ;
	}
}

BOOL WINAPI DllMain(HINSTANCE hinstDLL, DWORD fdwReason, LPVOID lpReserved)
{
    switch (fdwReason) 
    {
    case DLL_PROCESS_ATTACH:
		//MessageBox(NULL, "[INJECT] Begin attach!\n", "injectdll", MB_OK);
		Setup();
        break;
	
    case DLL_THREAD_ATTACH:
        break;

    case DLL_THREAD_DETACH:
        break;

    case DLL_PROCESS_DETACH:
        break;
    }
    return TRUE;
}
