#include <windows.h>
#include <stdio.h>

int main()
{
	TEXTMETRIC tm;
	HDC hdc;
	hdc = CreateDCA(TEXT("DISPLAY"),NULL,NULL,NULL);
	GetTextMetricsA(hdc, &tm);
	return 0;
}
