// ----------------------------------- //
//           StickyApp32 v1.0          //
//  Copyright 1997, 1998 Yariv Kaplan  //
//          WWW.INTERNALS.COM          //
// ----------------------------------- //

#include <windows.h>
#include "HookAPI.h"

typedef HANDLE (__stdcall *OPENPROCESS_PROC)(DWORD, BOOL, DWORD);

OPENPROCESS_PROC pOpenProcess = NULL;
 
HANDLE __stdcall OpenProcess_Handler(DWORD dwDesiredAccess, BOOL bInheritHandle, DWORD dwProcessId)
{
  HANDLE RetValue = NULL;
  HWND hWnd;
  DWORD ProcessId;

  hWnd = FindWindow("ThunderRT5Form", "StickyApp32");

  GetWindowThreadProcessId(hWnd, &ProcessId);

  if (dwProcessId != ProcessId)
    RetValue = pOpenProcess(dwDesiredAccess, bInheritHandle, dwProcessId);

  return RetValue;
}


__declspec(dllexport) LRESULT CALLBACK HookFunction(int code, WPARAM wParam, LPARAM lParam)
{
  if (pOpenProcess == NULL)
    pOpenProcess = (OPENPROCESS_PROC)HookAPIFunction(GetModuleHandle(NULL), "KERNEL32.DLL", "OpenProcess", (PROC)OpenProcess_Handler);

  return false;
}


BOOL WINAPI DllMain(HANDLE hInst, ULONG dwReason, LPVOID lpReserved)
{
  switch (dwReason)
  {
    case DLL_PROCESS_ATTACH:

      DisableThreadLibraryCalls(hInst);

    break;
  }

  return true;
}
